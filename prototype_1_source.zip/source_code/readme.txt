PICO-8 PROTOTYPE I - "Jump Cube"

if you somehow found use out of this, consider dropping a donation over @
https://actuallykron.itch.io/jump-cube-pico-8

cheers
- kron